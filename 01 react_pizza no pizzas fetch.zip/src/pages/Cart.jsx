import React from 'react';

const Cart = () => {
    return (
        <div>
            <h1>Корзина</h1>
        </div>
    );
};

export default Cart;
